package testtest.copy;

public class ProjectRun {

	public static void main(String[] args) {

		new InitialScreen();
	}//main

}//class
